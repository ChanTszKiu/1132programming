﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace ConsoleSnakeGame
{
    class Program
    {
        // 遊戲區域尺寸
        static int width = 40;
        static int height = 20;

        // 蛇身座標列表
        static List<Position> snake = new List<Position>();

        // 食物位置
        static Position food;

        // 初始方向往右
        static Direction direction = Direction.Right;

        // 隨機物件用來產生食物位置
        static Random rand = new Random();

        // 遊戲結束旗標
        static bool gameOver = false;

        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Init();

            int speed = 100;      // 初始速度（毫秒）
            bool paused = false;  // 是否暫停

            while (!gameOver)
            {
                // 處理鍵盤輸入
                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey(true).Key;

                    // 按 P 鍵暫停 / 繼續
                    if (key == ConsoleKey.P)
                        paused = !paused;
                    else if (!paused)
                        ChangeDirection(key);
                }

                // 執行移動與繪製畫面（非暫停時）
                if (!paused)
                {
                    Move(ref speed);
                    Draw();
                }

                Thread.Sleep(speed); // 控制速度
            }

            Console.SetCursorPosition(0, height + 3);
            Console.WriteLine("Game Over! Press any key to exit...");
            Console.ReadKey();
        }

        // 初始化遊戲狀態
        static void Init()
        {
            snake.Clear();
            snake.Add(new Position(10, 10));
            snake.Add(new Position(9, 10));
            snake.Add(new Position(8, 10));
            direction = Direction.Right;
            GenerateFood();
        }

        // 繪製畫面
        static void Draw()
        {
            Console.Clear();

            // 畫出邊框
            for (int i = 0; i <= width; i++)
            {
                Console.SetCursorPosition(i, 0);
                Console.Write("#");
                Console.SetCursorPosition(i, height);
                Console.Write("#");
            }
            for (int i = 0; i <= height; i++)
            {
                Console.SetCursorPosition(0, i);
                Console.Write("#");
                Console.SetCursorPosition(width, i);
                Console.Write("#");
            }

            // 畫出食物
            Console.SetCursorPosition(food.X, food.Y);
            Console.Write("O");

            // 畫出蛇
            foreach (var pos in snake)
            {
                Console.SetCursorPosition(pos.X, pos.Y);
                Console.Write("*");
            }

            // 顯示分數
            Console.SetCursorPosition(0, height + 1);
            Console.Write($"Score: {snake.Count - 3}");

            // 顯示提示文字
            Console.SetCursorPosition(0, height + 2);
            Console.Write("按下 P 可暫停 / 繼續遊戲");
        }

        // 處理蛇的移動與碰撞邏輯
        static void Move(ref int speed)
        {
            Position head = snake[0];
            Position newHead = new Position(head.X, head.Y);

            // 根據方向移動蛇頭
            switch (direction)
            {
                case Direction.Up: newHead.Y--; break;
                case Direction.Down: newHead.Y++; break;
                case Direction.Left: newHead.X--; break;
                case Direction.Right: newHead.X++; break;
            }

            // 碰牆或碰到自己 -> 遊戲結束
            if (newHead.X == 0 || newHead.X == width || newHead.Y == 0 || newHead.Y == height || snake.Contains(newHead))
            {
                gameOver = true;
                return;
            }

            // 插入新的頭部位置
            snake.Insert(0, newHead);

            // 是否吃到食物
            if (newHead.X == food.X && newHead.Y == food.Y)
            {
                GenerateFood();

                // 每吃 5 個食物加快速度（最低到 40ms）
                int level = snake.Count - 3;
                if (level % 5 == 0 && speed > 40)
                    speed -= 10;
            }
            else
            {
                // 沒吃到食物則移除尾部（不變長）
                snake.RemoveAt(snake.Count - 1);
            }
        }

        // 變更方向（避免反方向）
        static void ChangeDirection(ConsoleKey key)
        {
            switch (key)
            {
                case ConsoleKey.UpArrow:
                    if (direction != Direction.Down) direction = Direction.Up;
                    break;
                case ConsoleKey.DownArrow:
                    if (direction != Direction.Up) direction = Direction.Down;
                    break;
                case ConsoleKey.LeftArrow:
                    if (direction != Direction.Right) direction = Direction.Left;
                    break;
                case ConsoleKey.RightArrow:
                    if (direction != Direction.Left) direction = Direction.Right;
                    break;
            }
        }

        // 隨機產生食物位置（不能在蛇身上）
        static void GenerateFood()
        {
            Position newFood;
            do
            {
                newFood = new Position(rand.Next(1, width - 1), rand.Next(1, height - 1));
            } while (snake.Contains(newFood));

            food = newFood;
        }

        // 移動方向列舉
        enum Direction { Up, Down, Left, Right }

        // 座標資料結構
        struct Position
        {
            public int X;
            public int Y;

            public Position(int x, int y)
            {
                X = x;
                Y = y;
            }

            public override bool Equals(object obj)
            {
                if (!(obj is Position)) return false;
                var p = (Position)obj;
                return p.X == X && p.Y == Y;
            }

            public override int GetHashCode()
            {
                return X * 397 ^ Y;
            }
        }
    }
}
